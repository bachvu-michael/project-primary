CKEDITOR.plugins.setLang( 'widgets', 'en', {
	title: 'Widget configurator',
	toolbar: 'Widgets'
} );