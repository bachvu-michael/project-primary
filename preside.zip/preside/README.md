Preside
=======

[![Build Status](https://travis-ci.org/pixl8/Preside-CMS.svg?branch=stable "Stable")](https://travis-ci.org/pixl8/Preside-CMS)

[![Slack Status](https://presidecms-slack.herokuapp.com/badge.svg)](https://presidecms-slack.herokuapp.com/)

[![GetBadges Game](https://pixl8-preside-cms.getbadges.io/shield/company/pixl8-preside-cms)](https://pixl8-preside-cms.getbadges.io/?ref=shield-game)

Preside is an open source CMS for the [Lucee Server](http://lucee.org) built on the [ColdBox MVC Framework](http://www.coldbox.org). It is developed and maintained by [Pixl8 Interactive](http://www.pixl8.co.uk).

[Website (https://www.preside.org)](https://www.preside.org)

[Documentation and quick start guide (https://docs.presidecms.org)](https://docs.preside.org)
